#include"Main_Game.h"
#include<iostream>
using namespace sf;
int main()
{
	Main_Game game;
	game.renderwindow();
	
	system("pause");
	return 0;
}